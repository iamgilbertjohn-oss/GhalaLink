# GhalaLink - Main file is index.html - 500KB - GitHub safe (<25MB)

Admin Code: ADMIN2025

Features: 110 warehouses, Maharage search, Robusta, language pure SW/EN, admin separate

To upload to GitHub:
1. Unzip this folder
2. On GitHub repo page, click Add file -> Upload files
3. DRAG THE FILES INSIDE (index.html, README.md) - NOT the zip itself
4. Commit

If you drag zip, GitHub will say Yowza big file. Unzip first!